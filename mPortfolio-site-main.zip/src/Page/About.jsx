import React from "react";
import MainCom from "../Components/MainCom";
import "../Components/styleCom.css";

export const About = () => {
  return (
    <div>
      <MainCom/>
    </div>
  );
};

export default About;
